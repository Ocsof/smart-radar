#ifndef __PIR__
#define __PIR__

class Pir{
public:
    virtual bool detected() = 0;
};

#endif