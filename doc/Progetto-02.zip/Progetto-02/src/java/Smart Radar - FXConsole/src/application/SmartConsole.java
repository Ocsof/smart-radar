package application;

public class SmartConsole {
	/*Cambiare il nome in base alla propria porta seriale (esempio su un pc apple: "/dev/cu.usbmodem1421").
	  Il nome è consultabile facilmente dall'IDE di arduino.*/
	private final CommChannel channel = new SerialCommChannel("COM10",9600);
	SampleController controller;
	
	public SmartConsole(SampleController contr) throws InterruptedException {
		controller = contr;
		communicating();
	}
		
	public void communicating() throws InterruptedException {
		Thread thread = new Thread(){
			public void run(){
				while(true) {
					try {
						Thread.sleep(1000);
						controller.setText("Ready");
						while(true) {
							if(channel.isMsgAvailable()) {								
								String msg = channel.receiveMsg();
								if(msg.equals("on")) {
									controller.setAlarm(true);
								} else if(msg.equals("off")) {
									controller.setAlarm(false);
								} else {
									controller.setText("Received:  " + msg);	
								}
							}
						}
					} catch (InterruptedException e) {
						channel.close();
					}
				}
			}
		};
		thread.start();
	}
		
	public CommChannel getChannel() {
		return this.channel;
	}
}

